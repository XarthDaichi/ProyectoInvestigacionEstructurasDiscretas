# Carpeta de Anexos
En esta carpeta se guardan las implementaciones instrumentadas de cada algoritmo por separado, y algunos datos de prueba para comprobar la funcionalidad del algoritmo.

En los archivos .ipynb se encuentran las implementaciones instrumentada y sin instrumentar de sus respectivos algoritmos

En el archivo todos.ipynb esta las instrumentaciones juntas para generar una gráfica con todos los algoritmos usado en el documento

En el archivo pruebas.ipynb están las pruebas de harrypotter (para el cual también se le junta el harrypotter1.txt para hacer la prueba) y las de ADN